
    areaT=round(areaT1+areaT2+areaT3+areaT4,